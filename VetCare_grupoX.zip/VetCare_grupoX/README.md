# 🐾 VetCare - Sistema de Gestión de Citas

## 📌 Descripción
Este proyecto implementa un sistema básico para organizar citas y registrar tratamientos veterinarios para el emprendimiento **VetCare**, especializado en atención veterinaria a domicilio.

El objetivo es evitar citas duplicadas y almacenar información clínica de manera organizada, aplicando programación con funciones en Python.

---

## 📚 Funcionalidades

### ✔ Registrar citas
- Recibe datos del cliente, mascota y horario.
- Calcula automáticamente los horarios disponibles.
- Evita duplicaciones.

### ✔ Registrar tratamientos
- Guarda historial de atenciones para cada mascota.

### ✔ Ver agenda
- Muestra todas las citas registradas.

### ✔ Ver historial del paciente
- Filtra tratamientos según el nombre de la mascota.

---

## 🛠 Tecnologías usadas
- Python 3
- Manejo de funciones
- Listas y diccionarios
- Parámetros y valores retornados
- Uso controlado de variables locales/globales

---

## ▶ ¿Cómo ejecutar?

En consola:

```bash
python VetCare_grupoX.py
```

---

## 👥 Autores
Trabajo grupal — Curso de Programación Python.
