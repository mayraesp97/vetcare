# ============================================================
#   Proyecto VetCare - Gestión de Citas y Tratamientos
#   Archivo: VetCare_grupoX.py
# ============================================================

from datetime import datetime

# ------------------------------------------------------------
#   Función: mostrar_menu
# ------------------------------------------------------------
def mostrar_menu():
    print("\n===== SISTEMA DE GESTIÓN VETCARE =====")
    print("1. Registrar nueva cita")
    print("2. Registrar tratamiento de una mascota")
    print("3. Ver agenda completa")
    print("4. Ver historial de un paciente")
    print("5. Salir")
    return input("Seleccione una opción: ")

# ------------------------------------------------------------
#   Función: calcular_horarios_disponibles
# ------------------------------------------------------------
def calcular_horarios_disponibles(citas):
    horarios_base = ["09:00", "10:00", "11:00", "12:00",
                     "14:00", "15:00", "16:00", "17:00"]

    ocupados = [c["hora"] for c in citas]
    disponibles = [h for h in horarios_base if h not in ocupados]

    return disponibles

# ------------------------------------------------------------
#   Función: registrar_cita
# ------------------------------------------------------------
def registrar_cita(citas):
    print("\n=== Registrar Nueva Cita ===")

    disponibles = calcular_horarios_disponibles(citas)

    if not disponibles:
        print("No hay horarios disponibles para hoy.")
        return citas

    print("\nHorarios disponibles:")
    for h in disponibles:
        print("-", h)

    cliente = input("Nombre del dueño: ")
    mascota = input("Nombre de la mascota: ")
    hora = input("Ingrese hora (HH:MM) según lista: ")

    if hora not in disponibles:
        print("❌ Error: El horario no está disponible.")
        return citas

    nueva_cita = {
        "cliente": cliente,
        "mascota": mascota,
        "hora": hora,
        "fecha": datetime.now().strftime("%d-%m-%Y")
    }

    citas.append(nueva_cita)
    print("✅ Cita registrada exitosamente.")

    return citas

# ------------------------------------------------------------
#   Función: registrar_tratamiento
# ------------------------------------------------------------
def registrar_tratamiento(historial):
    print("\n=== Registrar Tratamiento ===")

    mascota = input("Nombre de la mascota: ")
    tratamiento = input("Descripción del tratamiento: ")

    nueva_atencion = {
        "mascota": mascota,
        "tratamiento": tratamiento,
        "fecha": datetime.now().strftime("%d-%m-%Y %H:%M")
    }

    historial.append(nueva_atencion)
    print("✅ Tratamiento registrado correctamente.")

    return historial

# ------------------------------------------------------------
#   Función: ver_agenda
# ------------------------------------------------------------
def ver_agenda(citas):
    print("\n===== AGENDA COMPLETA =====")
    if not citas:
        print("No hay citas registradas.")
        return

    for c in citas:
        print(f"{c['fecha']} - {c['hora']} | {c['mascota']} ({c['cliente']})")

# ------------------------------------------------------------
#   Función: ver_historial
# ------------------------------------------------------------
def ver_historial(historial):
    print("\n===== HISTORIAL CLÍNICO =====")
    mascota = input("Ingrese el nombre de la mascota: ")

    filtrado = [h for h in historial if h["mascota"] == mascota]

    if not filtrado:
        print("No hay historial para esta mascota.")
        return

    for h in filtrado:
        print(f"{h['fecha']} - {h['tratamiento']}")

# ------------------------------------------------------------
#   FUNCIÓN PRINCIPAL
# ------------------------------------------------------------
def main():
    citas = []       # Lista local
    historial = []   # Lista local

    while True:
        opcion = mostrar_menu()

        if opcion == "1":
            citas = registrar_cita(citas)
        elif opcion == "2":
            historial = registrar_tratamiento(historial)
        elif opcion == "3":
            ver_agenda(citas)
        elif opcion == "4":
            ver_historial(historial)
        elif opcion == "5":
            print("Saliendo del sistema... ¡Hasta pronto!")
            break
        else:
            print("❌ Opción no válida.")

# Ejecutar programa
if __name__ == "__main__":
    main()
